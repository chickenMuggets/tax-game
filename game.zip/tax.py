import tkinter.messagebox
import pip
import os
import time
from tkinter import *
import tax_calculator
import random
#detects if pygame is installed and if it isn't it installs it
import importlib.util
spec = importlib.util.find_spec("pygame")
if spec is None:
    pip.main(["install","pygame"])

import pygame
import webbrowser
#defining the menu to being the main screen
menu = "main"
mode = False
antialased = True
# Initialize Pygame
pygame.init()
my_font = pygame.font.SysFont('Segoe UI', 20, bold=True)
sleeper = False
sleeper_long = False

def is_text_clicked(worlds_enter_rect, mouse_pos):
    return worlds_enter_rect.collidepoint(mouse_pos)

#changes the background image to a blurred version
background_image_blurred = pygame.image.load("media/menu_blurred.png")
background_image = pygame.image.load("media/menu.png")

# Load and display the computer image with rounded corners
def round_image(image, radius):
    rect = image.get_rect()
    mask = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
    pygame.draw.rect(mask, (0, 0, 0, 0), mask.get_rect())
    pygame.draw.rect(mask, (255, 255, 255, 255), mask.get_rect(), border_radius=radius)
    rounded_image = image.copy()
    rounded_image.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
    return rounded_image

#Job creator code
computer_image = pygame.image.load("media/computer.png")
computer_image = pygame.transform.scale(computer_image, (125, 125))
computer_image = round_image(computer_image, 10)  # Adjust the radius as needed

#Tax creator code
tax_image = pygame.image.load("media/taxes.png")
tax_image = pygame.transform.scale(tax_image, (125, 125))
tax_image = round_image(tax_image, 10)  # Adjust the radius as needed

#year image code
year_image = pygame.image.load("media/year.png")
year_image = pygame.transform.scale(year_image, (125, 125))
year_image = round_image(year_image, 10)  # Adjust the radius as needed

#retire code
retire = pygame.image.load("media/retire.png")
retire = pygame.transform.scale(retire, (125, 125))
retire = round_image(retire, 10)  # Adjust the radius as needed

#super image code
superimg = pygame.image.load("media/super.png")
superimg = pygame.transform.scale(superimg, (125, 125))
superimg = round_image(superimg, 10)  # Adjust the radius as needed

#court image code
court_image = pygame.image.load("media/court.png")
court_image = pygame.transform.scale(court_image, (125, 125))
court_image = round_image(court_image, 10)  # Adjust the radius as needed


# Set up the display
window_size = (800, 600)
window = pygame.display.set_mode(window_size)
pygame.display.set_caption("Tax Game")

# Initialize the clock
clock = pygame.time.Clock()
# Main loop
running = True
while running:
    #if the game is told to exit it acually exits
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    # Load the background image
    window.blit(background_image, (0, 0))
    
    #the code below indicates the different modes of the code
    if menu == "main":
        worlds_enter_text = my_font.render('worlds', antialased, (0, 0, 0),)
        sources_text = my_font.render('sources', antialased, (0, 0, 0))
        exit_text = my_font.render('exit', antialased, (0, 0, 0))
        if pygame.mouse.get_pressed()[0]:
            mouse_pos = pygame.mouse.get_pos()
            if is_text_clicked(worlds_enter_rect, mouse_pos):
                menu = "worlds"
            if is_text_clicked(exit_rect, mouse_pos):
                quit()
            if is_text_clicked(sources_rect,mouse_pos):
                menu = "sources"
        worlds_enter_rect = exit_text.get_rect(center=(window_size[0] // 2, window_size[1] // 2 - 50))
        sources_rect = sources_text.get_rect(center=(window_size[0] // 2 + 15, window_size[1] // 2 - 20))
        exit_rect = exit_text.get_rect(center=(window_size[0] // 2, window_size[1] // 2 + 10))
        
        # Draw the text
        window.blit(worlds_enter_text, worlds_enter_rect)
        window.blit(sources_text, sources_rect)
        window.blit(exit_text, exit_rect)
    elif menu == "worlds":
        window.blit(background_image_blurred, (0, 0))
        y_offset = 0
        #locates the files in the worlds folder ending in the proper extension
        worlds = [filename for filename in os.listdir('worlds') if filename.endswith('.taxwrld')]
        worlds.sort(key=lambda x: (x != "Create World.taxwrld", x))
        
        for filename in worlds:
            world_text = my_font.render(filename.replace(".taxwrld", ""), antialased, (0, 0, 0))
            world_rect = world_text.get_rect(center=(window_size[0] // 2, window_size[1] // 2 + y_offset))
            window.blit(world_text, world_rect)
            
            if pygame.mouse.get_pressed()[0]:
                mouse_pos = pygame.mouse.get_pos()
                if world_rect.collidepoint(mouse_pos):
                    worldEntered = filename
                    if worldEntered != "Create World.taxwrld" or worldEntered != "Delete World.taxwrld":
                        menu = "inWorld"
                    if worldEntered == "Create World.taxwrld":
                        menu = "createWorld"
                    elif worldEntered == "Delete World.taxwrld":
                        menu = "deleteWorld"
                    openWorld = open(f'worlds\\{filename}', 'r')
            y_offset += 40  # Adjust this value to change the spacing between the texts
        keys = pygame.key.get_pressed()
        if keys[pygame.K_ESCAPE]:
            menu = "main"
    elif menu == "deleteWorld":
        root = Tk()
        root.title("World Menu")
        root.geometry("300x200")

        def delete_world():
            selected_world = world_var.get()
            if selected_world:
                file_path = os.path.join('worlds', f"{selected_world}.taxwrld")
                if os.path.exists(file_path):
                    os.remove(file_path)
                    tkinter.messagebox.showinfo("Success", f"Deleted world: {selected_world}")
                    root.destroy()
                    menu = "worlds"
                else:
                    tkinter.messagebox.showerror("Error", "World does not exist!")

        worlds = [filename.replace(".taxwrld", "") for filename in os.listdir('worlds') if filename.endswith('.taxwrld') and filename != "Create World.taxwrld" and filename != "Delete World.taxwrld"]
        world_var = StringVar(root)
        world_var.set(worlds[0] if worlds else "")

        label = Label(root, text="Select World:")
        label.pack(pady=10)

        dropdown = OptionMenu(root, world_var, *worlds)
        dropdown.pack(pady=10)

        delete_button = Button(root, text="Delete World", command=delete_world)
        delete_button.pack(pady=10)

        root.mainloop()
        menu = "worlds"
    elif menu == "inWorld":
        #changes the background image to a blurred version
        window.blit(background_image_blurred, (0, 0))
        for line in openWorld.readlines():
            if "<money>" in line:
                money = int(line.replace("<money> ", ""))
            if "<year>" in line:
                year = int(line.replace("<year> ", ""))
            if "<job>" in line:
                job = line.replace("<job> ", "").replace("\n","")
            if "<super>" in line:
                superused = line.replace("<job> ", "").replace("\n","")
        
        money_text = my_font.render(f'Money: {money}', antialased, (0, 0, 0))
        money_rect = money_text.get_rect(center=(window_size[0] // 2, 50))
        window.blit(money_text, money_rect)
        job_text = my_font.render(f'Job status: {job}', antialased, (0, 0, 0))
        job_rect = job_text.get_rect(center=(window_size[0] // 2, 30))
        window.blit(job_text, job_rect)

        #text for job
        job_text = my_font.render(f'Job status: {job}', antialased, (0, 0, 0))
        job_rect = job_text.get_rect(center=(window_size[0] // 2, 30))
        window.blit(job_text, job_rect)
        
        #text for the year
        year_text = my_font.render(f'Year: {year}', antialased, (0, 0, 0))
        year_rect = year_text.get_rect(center=(window_size[0] // 2, 70))
        window.blit(year_text, year_rect)
        
        #text
        computer_text = my_font.render('Manage job', antialased, (0, 0, 0))
        computer_rect = computer_text.get_rect(topleft=(105,225))
        window.blit(computer_text, computer_rect)
        computer_rect = computer_image.get_rect(topleft=(100, 100))  # Update the rect to match the image position
        if pygame.mouse.get_pressed()[0]:
            mouse_pos = pygame.mouse.get_pos()
            if computer_rect.collidepoint(mouse_pos):
                # Add logic to manage job here
                menu = "job"

        #image blit
        window.blit(computer_image, (100, 100))
        window.blit(tax_image, (250, 100))
        if year >= 65 and job != "unemployed":
            window.blit(retire, (400, 100))
            window.blit(superimg, (550, 100))
            window.blit(year_image, (100, 260))
        else:
            window.blit(superimg, (400, 100))
            window.blit(year_image, (550, 100))
        
        if pygame.mouse.get_pressed()[0]:
            mouse_pos = pygame.mouse.get_pos()
            if tax_image.get_rect(topleft=(250, 100)).collidepoint(mouse_pos):
                menu = "tax"
            if year < 65:
                if year_image.get_rect(topleft=(550, 100)).collidepoint(mouse_pos):
                    openWorld = open(f'worlds\\{worldEntered}', 'r')
                    lines = openWorld.readlines()
                    lines = openWorld.readlines()

                    openWorld = open(f'worlds\\{worldEntered}', 'r')
                    lines = openWorld.readlines()
                    for i in range(len(lines)):
                        if "<year>" in lines[i]:
                            lines[i] = f"<year> {year}\n"
                            openWorld = open(f'worlds\\{worldEntered}', 'w')
                            openWorld.writelines(lines)
                            openWorld.close()
                    openWorld = open(f'worlds\\{worldEntered}', 'r')
                    
                    for i in range(len(lines)):
                        if "<year>" in lines[i]:
                            current_year = int(lines[i].replace("<year> ", ""))
                            lines[i] = f"<year> {current_year + 1}\n"
                            year = int(lines[i].replace("<year> ", ""))
                            if job == "cashier":
                                money += 10000
                                money_this_year = 10000
                            elif job == "teacher":
                                money += 80000
                                money_this_year = 80000
                            elif job == "engineer":
                                money += 120000
                                money_this_year = 120000
                            elif job == "doctor":
                                money += 150000
                                money_this_year = 150000
                            elif job == "programmer":
                                money += 100000
                                money_this_year = 100000
                            elif job == "unemployed":
                                money += 0
                                money_this_year = 0
                            openWorld = open(f'worlds\\{worldEntered}', 'r')
                    lines = openWorld.readlines()
                    openWorld = open(f'worlds\\{worldEntered}', 'w')
                    for i in range(len(lines)):
                        if "<money>" in lines[i]:
                            lines[i] = f"<money> {money}\n"
                            openWorld.writelines(lines)
                        if "<year>" in lines[i]:
                            lines[i] = f"<year> {year}\n"
                            openWorld.writelines(lines)

                        if "<TEA>" in lines[i]:
                            if tax_calculator.calculate_tax(money_this_year) > 0:
                                lines[i] = f"<TEA> {tax_calculator.calculate_tax(money_this_year)}\n"
                                openWorld.writelines(lines)
                                
                    openWorld.close()
                        
                    openWorld = open(f'worlds\\{worldEntered}', 'r')
                    if year == 2:
                        tkinter.messagebox.showinfo("ATO", f"Remember to pay your taxes for the amount you earned every year. Otherwise it is considered tax evasion.")
                    
                    """
                    cashier = 10000
                    teacher = 80000
                    programmer  = 100000
                    engineer= 120000
                    doctor  = 150000
                    """
                    openWorld = open(f'worlds\\{worldEntered}', 'w')
                    openWorld.writelines(lines)
                    openWorld.close()
                    openWorld = open(f'worlds\\{worldEntered}', 'r')
                    sleeper_long = True
                if superimg.get_rect(topleft=(400, 100)).collidepoint(mouse_pos):
                    menu = "super"
            else:
                if retire.get_rect(topleft=(200, 260)).collidepoint(mouse_pos):
                    print("retire")
                    job = "none"
                    openWorld = open(f'worlds\\{worldEntered}', 'r')
                    lines = openWorld.readlines()
                    for i in range(len(lines)):
                        if "<job>" in lines[i]:
                            lines[i] = "<job> none\n"
                    openWorld = open(f'worlds\\{worldEntered}', 'w')
                    openWorld.writelines(lines)
                    openWorld.close()
        
        #text
        taxes_text = my_font.render('Taxes', antialased, (0, 0, 0))
        taxes_rect = taxes_text.get_rect(topleft=(260,225))
        window.blit(taxes_text, taxes_rect)
        if pygame.mouse.get_pressed()[0]:
            mouse_pos = pygame.mouse.get_pos()
            if taxes_rect.collidepoint(mouse_pos):
                menu = "tax"

        

        keys = pygame.key.get_pressed()
        if keys[pygame.K_ESCAPE]:
            menu = "worlds"
            sleeper = True
    elif menu == "createWorld":
        root = Tk()
        root.title("World Menu")
        root.geometry("200x200")

        def create_world():
            world_name = entry.get()
            if world_name:
                file_path = os.path.join('worlds', f"{world_name}.taxwrld")
                if os.path.exists(file_path) and world_name != "Create World" and world_name != "Delete World":
                    tkinter.messagebox.showerror("Error", "World with this name already exists!")
                    return
                if world_name == "Create World" or world_name == "Delete World":
                    tkinter.messagebox.showerror("Error", f"World name cannot be '{world_name}'")
                file_path = os.path.join('worlds', f"{world_name}.taxwrld")
                with open(file_path, 'w') as f:
                    f.write(f"<money> 1000\n<job> unemployed\n<stocks> none\n<hasGoneToJail> 0\n<taxEvasion> 0\n<creative> {mode}\n<year> 1\n<METY> \n<TEA> 0")
                menu = "worlds"  # Change the menu to worlds instead of quitting pygame
                root.destroy()

        label = Label(root, text="World Name:")
        label.pack(pady=10)

        entry = Entry(root)
        entry.pack(pady=10)
        creative = Checkbutton(root, text="Creative Mode", variable=mode)
        creative.pack(pady=10)
        

        button = Button(root, text="Create World", command=create_world)
        button.pack(pady=10)

        root.mainloop()
        menu = "worlds"
    elif menu == "job":
        job_text = my_font.render('Select Job:', antialased, (0, 0, 0))
        job_rect = job_text.get_rect(center=(window_size[0] // 2, window_size[1] // 2 - 50))
        window.blit(job_text, job_rect)
        jobs = ["cashier - $10000", "teacher - $80000","programmer - $100000", "engineer - $120000", "doctor - $150000"]

        y_offset = 0
        for jobw in jobs:
            job_text = my_font.render(jobw, antialased, (0, 0, 0))
            job_rect = job_text.get_rect(center=(window_size[0] // 2, window_size[1] // 2 + y_offset))
            window.blit(job_text, job_rect)
            if pygame.mouse.get_pressed()[0]:
                mouse_pos = pygame.mouse.get_pos()
                if job_rect.collidepoint(mouse_pos):
                    if jobw == "cashier - $10000":
                        jobChance = random.randint(1,10)
                        if jobChance > 1:
                            job = jobw
                            menu = "inWorld"
                        else:
                            tkinter.messagebox.showinfo("Job", "You did not get the job")
                    elif jobw == "teacher - $80000":
                        jobChance = random.randint(1,3)
                        if jobChance == 1:
                            job = jobw
                            menu = "inWorld"
                        else:
                            tkinter.messagebox.showinfo("Job", "You did not get the job")
                    elif jobw == "programmer - $100000":
                        jobChance = random.randint(1,2)
                        if jobChance == 1:
                            job = jobw
                            menu = "inWorld" 
                        else:
                            tkinter.messagebox.showinfo("Job", "You did not get the job")
                    elif jobw == "engineer - $120000":
                        jobChance = random.randint(1,10)
                        if jobChance > 9:
                            job = jobw
                            menu = "inWorld"
                        else:
                            tkinter.messagebox.showinfo("Job", "You did not get the job")
                    elif jobw == "doctor - $150000":
                        jobChance = random.randint(1,100)
                        if jobChance > 95:
                            job = jobw
                            menu = "inWorld"
                        else:
                            tkinter.messagebox.showinfo("Job", "You did not get the job")
                        


                    openWorld = open(f'worlds\\{worldEntered}', 'r')
                    lines = openWorld.readlines()
                    for i in range(len(lines)):
                        if "<job>" in lines[i]:
                            lines[i] = f"<job> {job}\n"
                            openWorld = open(f'worlds\\{worldEntered}', 'w')
                            openWorld.writelines(lines)
                            openWorld.close()
                    openWorld = open(f'worlds\\{worldEntered}', 'r')
            y_offset += 40
        window.blit(job_text, job_rect)
        if pygame.key.get_pressed()[pygame.K_ESCAPE]:
            menu = "inWorld"
            sleeper_long = True               
    elif menu == "tax":
        tax_info_text = my_font.render('what is tax', antialased, (0,0,0))
        tax_info_rect = tax_info_text.get_rect(center=(window_size[0] // 2, window_size[1] // 2 - 100))
        window.blit(tax_info_text, tax_info_rect)
        mouse_pos = pygame.mouse.get_pos()
        tax_help_text = my_font.render('how does tax help my community', antialased, (0,0,0))
        tax_help_rect = tax_help_text.get_rect(center=(window_size[0] // 2, window_size[1] // 2 - 160))
        window.blit(tax_help_text, tax_help_rect)
        mouse_pos = pygame.mouse.get_pos()

        
        if pygame.key.get_pressed()[pygame.K_ESCAPE]:
                menu = "inWorld"
        # Tax manager code
        tax_manager_running = True
        input_active = False
        user_text = ''
        input_box = pygame.Rect(window_size[0] // 2 - 100, window_size[1] // 2, 200, 50)
        color_inactive = pygame.Color('lightskyblue3')
        color_active = pygame.Color('dodgerblue2')
        color = color_inactive

        while tax_manager_running:
            if tax_info_rect.collidepoint(mouse_pos):
                tax_info_other_text = pygame.font.SysFont('Segoe UI', 20).render('Tax is a certain amount of money from your income that is given to the government', antialased, (0,0,0))
                tax_info_other_rect = tax_info_other_text.get_rect(center=(window_size[0] // 2, window_size[1] // 2 - 80))
                window.blit(tax_info_other_text, tax_info_other_rect)
            else:
                window.blit(background_image_blurred, (0, 0))
                window.blit(tax_info_text, tax_info_rect)
                window.blit(tax_help_text, tax_help_rect)
            if tax_help_rect.collidepoint(mouse_pos):
                tax_info_other_text = pygame.font.SysFont('Segoe UI', 20).render('tax helpes the community by funding projects like schools', antialased, (0,0,0))
                tax_info_other_rect = tax_info_other_text.get_rect(center=(window_size[0] // 2, window_size[1] // 2 - 80))
                window.blit(tax_info_other_text, tax_info_other_rect)

            mouse_pos = pygame.mouse.get_pos()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    tax_manager_running = False
                    running = False
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if input_box.collidepoint(event.pos):
                        input_active = not input_active
                    else:
                        input_active = False
                    color = color_active if input_active else color_inactive
                if event.type == pygame.KEYDOWN:
                    if input_active:
                        if event.key == pygame.K_RETURN:
                            try:
                                amount = int(user_text)
                                if amount > 0:
                                    # Update the world file with the new tax information
                                    openWorld = open(f'worlds\\{worldEntered}', 'r')
                                    lines = openWorld.readlines()
                                    for i in range(len(lines)):
                                        if "<money>" in lines[i]:
                                            current_money = int(lines[i].replace("<money> ", ""))
                                            lines[i] = f"<money> {current_money - amount}\n"
                                    openWorld = open(f'worlds\\{worldEntered}', 'w')
                                    openWorld.writelines(lines)
                                    openWorld.close()
                                    openWorld = open(f'worlds\\{worldEntered}', 'r')
                                    tax_manager_running = False
                                    menu = "inWorld"
                                else:
                                    tkinter.messagebox.showwarning("ATO", "We don't give free money pal.")
                            except ValueError:
                                tkinter.messagebox.showinfo("Error", "Please enter a valid number!")
                            user_text = ''
                        elif event.key == pygame.K_BACKSPACE:
                            user_text = user_text[:-1]
                        else:
                            user_text += event.unicode
            txt_surface = my_font.render(user_text, antialased, color)
            width = max(200, txt_surface.get_width() + 10)
            input_box.w = width
            window.blit(txt_surface, (input_box.x + 5, input_box.y + 5))
            pygame.draw.rect(window, color, input_box, 2)
            pygame.display.flip()
            keys = pygame.key.get_pressed()
            if keys[pygame.K_ESCAPE]:
                tax_manager_running = False
                menu = "inWorld"
        def submit_tax():
            try:
                amount = int(entry.get())
                if amount > 0:
                    tkinter.messagebox.showinfo("Success", f"Submitted tax amount: {amount}")
                    # Update the world file with the new tax information
                    openWorld = open(f'worlds\\{worldEntered}', 'r')
                    lines = openWorld.readlines()
                    for i in range(len(lines)):
                        if "<money>" in lines[i]:
                            current_money = int(lines[i].replace("<money> ", ""))
                            lines[i] = f"<money> {current_money - amount}\n"
                    openWorld = open(f'worlds\\{worldEntered}', 'w')  
            except ValueError:
                tkinter.messagebox.showerror("Error", "Please enter a valid number!")
    elif menu == "court":
        window.blit(court_image, (0, 0))
    elif menu == "super":
        window.blit(background_image_blurred, (0, 0))
        super_text = my_font.render('Superannuation Information', antialased, (0, 0, 0))
        super_rect = super_text.get_rect(center=(window_size[0] // 2, window_size[1] // 2 - 50))
        window.blit(super_text, super_rect)

        super_info_text = my_font.render('Super is a way to save for retirement.', antialased, (0, 0, 0))
        super_info_rect = super_info_text.get_rect(center=(window_size[0] // 2, window_size[1] // 2))
        window.blit(super_info_text, super_info_rect)
        super_info_text = my_font.render('picking the right super is important as it can impact  your retirement funds', antialased, (0, 0, 0))
        super_info_rect = super_info_text.get_rect(center=(window_size[0] // 2, window_size[1] // 2 + 30))
        window.blit(super_info_text, super_info_rect)
        keys = pygame.key.get_pressed()
        if keys[pygame.K_ESCAPE]:
            menu = "inWorld"
            sleeper_long = True
    elif menu == "sources":
        window.blit(background_image_blurred, (0, 0))
        link_text = my_font.render('how does tax help my community', antialased, (0, 0, 255))
        link_rect = link_text.get_rect(center=(window_size[0] // 2, window_size[1] // 2 + 50))
        window.blit(link_text, link_rect)
        
        if pygame.mouse.get_pressed()[0]:
            mouse_pos = pygame.mouse.get_pos()
            if link_rect.collidepoint(mouse_pos):
                webbrowser.open("https://taxsuperandyou.gov.au/activity/civics-citizenship/how-tax-contributes-community-and-civic-life")
        keys = pygame.key.get_pressed()
        link_text = my_font.render('how does tax help my community', antialased, (0, 0, 255))
        link_rect = link_text.get_rect(center=(window_size[0] // 2, window_size[1] // 2 + 50))
        window.blit(link_text, link_rect)
        
        link_text = my_font.render('what is super', antialased, (0, 0, 255))
        link_rect = link_text.get_rect(center=(window_size[0] // 2, window_size[1] // 2 + 20))
        window.blit(link_text, link_rect)

        if pygame.mouse.get_pressed()[0]:
            mouse_pos = pygame.mouse.get_pos()
            if link_rect.collidepoint(mouse_pos):
                webbrowser.open("https://www.ato.gov.au/individuals-and-families/super-for-individuals-and-families/super/what-is-super")
        link_text = my_font.render('how to choose a super', antialased, (0, 0, 255))
        link_rect = link_text.get_rect(center=(window_size[0] // 2, window_size[1] // 2 + 80))
        window.blit(link_text, link_rect)

        if pygame.mouse.get_pressed()[0]:
            mouse_pos = pygame.mouse.get_pos()
            if link_rect.collidepoint(mouse_pos):
                webbrowser.open("https://www.ato.gov.au/individuals-and-families/super-for-individuals-and-families/super/choosing-a-super-fund")
        keys = pygame.key.get_pressed()
        if keys[pygame.K_ESCAPE]:
            tax_manager_running = False
            menu = "main"
            sleeper = True
    else:
        #this should only show if an error occured
        window.fill((0, 0, 0))
        tkinter.messagebox.showerror("Error", "ERROR CODE 1 look at documentation.md for more info")
        quit()
    #Displays FPS
    fps = clock.get_fps()
    fps_text = my_font.render(f'FPS: {int(fps)}', antialased, (0, 0, 0))
    window.blit(fps_text, (10, 10))
    clock.tick(6000)
    pygame.display.flip()
    #this code makes sleeping the game easyier by allowing me to change a varible to sleep the game for 0.1 seconds at the end of a frame
    if sleeper == True:
        time.sleep(0.1)
        sleeper = False
    #same as sleeper but sleeps an extra 2 ms
    if sleeper_long == True:
        time.sleep(0.3)
        pygame.display.flip()
        sleeper_long = False

pygame.quit()