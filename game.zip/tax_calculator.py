def calculate_tax(income):
    if income <= 18200:
        return 0
    elif income <= 45000:
        return (income - 18200) * 0.19
    elif income <= 120000:
        return 5092 + (income - 45000) * 0.325
    elif income <= 180000:
        return 29467 + (income - 120000) * 0.37
    else:
        return 51667 + (income - 180000) * 0.45
